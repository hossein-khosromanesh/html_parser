<?php


if (isset($_GET)) {
    echo 'PO_Number,';
    echo 'Tracking_Number,';
    echo 'Scheduled,';
    echo 'Customer,';
    echo 'Trade,';
    echo 'NTE,';
    echo 'Store_ID,';
    echo 'Phone_number,';
    echo 'location_address,';
    echo 'Street,';
    echo 'City,';
    echo 'State,';
    echo 'Zip_code';
    echo "\n";

    if (isset($_GET['PO_Number'])) {
        echo $_GET['PO_Number'] . ",";
    }
    if (isset($_GET['Tracking_Number'])) {
        echo $_GET['Tracking_Number'] . ",";
    }
    if (isset($_GET['Scheduled'])) {
        echo $_GET['Scheduled'] . ",";
    }
    if (isset($_GET['Customer'])) {
        echo $_GET['Customer'] . ",";
    }
    if (isset($_GET['Trade'])) {
        echo $_GET['Trade'] . ",";
    }
    if (isset($_GET['NTE'])) {
        echo $_GET['NTE'] . ",";
    }
    if (isset($_GET['Store_ID'])) {
        echo $_GET['Store_ID'] . ",";
    }
    if (isset($_GET['Phone_number'])) {
        echo $_GET['Phone_number'] . ",";
    }
    if (isset($_GET['location_address'])) {
        echo $_GET['location_address'] . ",";
    }
    if (isset($_GET['Street'])) {
        echo $_GET['Street'] . ",";
    }
    if (isset($_GET['City'])) {
        echo $_GET['City'] . ",";
    }
    if (isset($_GET['State'])) {
        echo $_GET['State'] . ",";
    }
    if (isset($_GET['Zip_code'])) {
        echo $_GET['Zip_code'];
    }


}

?>






