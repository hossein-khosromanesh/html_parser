chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (request.message === "start") {
            start();
        }
    }
);

function start() {

    Tracking_Number = document.getElementById('wo_number').innerText
    PO_Number = document.getElementById('po_number').innerText
    Scheduled = document.getElementById('scheduled_date').innerText
    Scheduled = Scheduled.replace(',', '')
    Time = Scheduled.split('\n')[1]
    Scheduled = Scheduled.split('\n')[0]
    Month = Scheduled.split(' ')[0]
    Day = Scheduled.split(' ')[1]
    Year = Scheduled.split(' ')[2]
    var monthNumber = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"].indexOf(Month.toLowerCase()) + 1;
    Time = convertTime12To24(Time)
    monthNumber = monthNumber.toLocaleString('en-US', {
        minimumIntegerDigits: 2,
        useGrouping: false
    })
    Scheduled = Year + "-" + monthNumber + "-" + Day + " " + Time
    Customer = document.getElementById('customer').innerText
    Trade = document.getElementById('trade').innerText
    NTE = document.getElementById('nte').innerText
    NTE = NTE.replace(',', '')
    NTE = NTE.replace('$', '')
    Store_ID = document.getElementById('location_name').innerText
    Phone_number = document.getElementById('location_phone').innerText
    Phone_number = Phone_number.replaceAll('-', '')
    location_address = document.getElementById('location_address').innerText
    Street = location_address.split('\n')[0]
    location_address = location_address.split('\n')[1]
    City = location_address.split(' ')[0]
    State = location_address.split(' ')[1]
    Zip_code = location_address.split(' ')[2]

    var dataArr = {
        PO_Number: PO_Number,
        Tracking_Number: Tracking_Number,
        Scheduled: Scheduled,
        Customer: Customer,
        Trade: Trade,
        NTE: NTE,
        Store_ID: Store_ID,
        Phone_number: Phone_number,
        location_address: location_address,
        Street: Street,
        City: City,
        State: State,
        Zip_code: Zip_code
    }

    chrome.runtime.sendMessage({
        data: dataArr
    });

    function convertTime12To24(time) {
        var hours = Number(time.match(/^(\d+)/)[1]);
        var minutes = Number(time.match(/:(\d+)/)[1]);
        var AMPM = time.match(/\s(.*)$/)[1];
        if (AMPM === "PM" && hours < 12) hours = hours + 12;
        if (AMPM === "AM" && hours === 12) hours = hours - 12;
        var sHours = hours.toString();
        var sMinutes = minutes.toString();
        if (hours < 10) sHours = "0" + sHours;
        if (minutes < 10) sMinutes = "0" + sMinutes;
        return (sHours + ":" + sMinutes);
    }

}









