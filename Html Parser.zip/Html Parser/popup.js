function popup() {
    chrome.tabs.query({currentWindow: true, active: true}, function (tabs) {
        var activeTab = tabs[0];
        chrome.tabs.sendMessage(activeTab.id, {"message": "start"});
    });

    // to receives data from content js
    chrome.runtime.onMessage.addListener(function (request) {
        sendTheDataToApi(request.data)
    });
}

// to send api and receives the csv file
function sendTheDataToApi(dataFromPage) {

    // console.log(dataFromPage)
    parametersToApi = 'PO_Number=' + dataFromPage.PO_Number + '&Tracking_Number=' + dataFromPage.Tracking_Number + '&Scheduled=' +
        dataFromPage.Scheduled + '&Customer=' + dataFromPage.Customer + '&Trade=' + dataFromPage.Trade + '&NTE=' + dataFromPage.NTE +
        '&Store_ID=' + dataFromPage.Store_ID + '&Phone_number=' + dataFromPage.Phone_number +
        '&location_address=' + dataFromPage.location_address +'&Street=' + dataFromPage.Street + '&City=' + dataFromPage.City + '&State=' +
        dataFromPage.State + '&Zip_code=' + dataFromPage.Zip_code

    let url = 'http://localhost/api/api.php?' + parametersToApi
console.log(url)
    fetch(url)
        .then((res) => {
            return res.blob();
        })
        .then((data) => {
            var a = document.createElement("a");
            a.href = window.URL.createObjectURL(data);
            a.download = "exportedData.csv";
            a.click();
        });
}

//check to start process after all dom loaded
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("button1").addEventListener("click", popup);
});